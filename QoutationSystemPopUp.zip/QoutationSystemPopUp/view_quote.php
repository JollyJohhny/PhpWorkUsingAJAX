<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_quote where QuoteNumber = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $id = $result['QuoteNumber'];
      $CustomerId = $result['CustomerId'];
    	$VendorId = $result['VendorId'];
    	$CopyQuoteNumber = $result['CopyQuoteNumber'];
    	$Address1 = $result['Address1'];
    	$Address2 = $result['Address2'];
    	$Contact = $result['Contact'];
    	$JobName = $result['JobName'];
    	$BidDate = $result['BidDate'];
    	$ReleaseDate = $result['ReleaseDate'];
    	$OrderByDate = $result['OrderByDate'];
    	$ShipByDate = $result['ShipByDate'];
    	$PhoneNumber = $result['PhoneNumber'];
    	$Status = $result['Status'];
      $PriceNotes = $result['PriceNotes'];

    	$Image = $result['LogoImage'];
    }


    echo "<div class='container'><h3>Customer Id</h3><p>$CustomerId</p>";
    echo "<h3>Vendor Id</h3><p>$VendorId</p>";
    echo "<h3>Copy Quot eNumber</h3><p>$CopyQuoteNumber</p>";
    echo "<h3>Address 1</h3><p>$Address1</p>";
    echo "<h3>Address 2</h3><p>$Address2</p>";
    echo "<h3>Contact</h3><p>$Contact</p>";
    echo "<h3>Job Name</h3><p>$JobName</p>";
    echo "<h3>Bid Date</h3><p>$BidDate</p>";
    echo "<h3>Release Date</h3><p>$ReleaseDate</p>";
    echo "<h3>Order By Date</h3><p>$OrderByDate</p>";
    echo "<h3>Ship By Date</h3><p>$ShipByDate</p>";
    echo "<h3>Phone Number</h3><p>$PhoneNumber</p>";
    echo "<h3>Price Notes</h3><p>$PriceNotes</p>";
    echo "<h3>Logo Image</h3><p>$Image</p></div>";

 }
?>
