  <?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_quote where QuoteNumber = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $id = $result['QuoteNumber'];
      $CustomerId = $result['CustomerId'];
    	$VendorId = $result['VendorId'];
    	$CopyQuoteNumber = $result['CopyQuoteNumber'];
    	$Address1 = $result['Address1'];
    	$Address2 = $result['Address2'];
    	$Contact = $result['Contact'];
    	$JobName = $result['JobName'];
    	$BidDate = $result['BidDate'];
    	$ReleaseDate = $result['ReleaseDate'];
    	$OrderByDate = $result['OrderByDate'];
    	$ShipByDate = $result['ShipByDate'];
    	$PhoneNumber = $result['PhoneNumber'];
    	$Status = $result['Status'];
      $PriceNotes = $result['PriceNotes'];

    	$Image = $result['LogoImage'];
    }

    $QueryForCustomers = "select * from tbl_customers";
    $resForCustomers = mysqli_query($conn,$QueryForCustomers);

    $QueryForVendors = "select * from tbl_vendors";
    $resForVendors = mysqli_query($conn,$QueryForVendors);


    echo "<div class='form-group'><div class='form-group'><label for='customerid'>Customer Id</label></br><select id='customerid' style='width:250px' class='form-control' name='CustomerId'><option value=$CustomerId>Select Customer</option></div></br>";
    while ($row = mysqli_fetch_array($resForCustomers)) {
  echo "<option value='".$row['CustomerId']."'>".$row['CompanyName']."</option>";
}
  echo "</select>";

  echo "<div class='form-group'><div class='form-group'><label for='vendorid'>Vendor Id</label></br><select id='vendorid' style='width:250px' class='form-control' name='VendorId'><option value=$VendorId>Select Vendor</option></div></br>";
  while ($row = mysqli_fetch_array($resForVendors)) {
echo "<option value='".$row['VendorId']."'>".$row['CompanyName']."</option>";
}
echo "</select>";



    echo "<div class='container'><div class='form-group'><input type='hidden' class='form-control' name='QuoteNumber' value=$id></div>";

    echo "<div class='form-group'><label for='CQN'>Copy Quote Number</label></br><input style='width:250px' id='CQN' type='text' class='form-control' name='CopyQuoteNumber' value='".$CopyQuoteNumber."'></div></br>";
    echo "<div class='form-group'><label for='address1'>Address 1</label></br><input style='width:250px' id='address1' type='text' class='form-control' name='Address1' value='".$Address1."'></div></br>";
    echo "<div class='form-group'><label for='address2'>Address 2</label></br><input style='width:250px' id='address2' type='text' class='form-control' name='Address2' value='".$Address2."'></div></br>";
    echo "<div class='form-group'><label for='contact'>Contact</label></br><input style='width:250px' id='contact' type='text' class='form-control' name='Contact' value='".$Contact."'></div></br>";
    echo "<div class='form-group'><label for='jobname'>Job Name</label></br><input style='width:250px' id='jobname' type='text' class='form-control' name='JobName' value=$JobName></div></br>";
    echo "<div class='form-group'><label for='biddate'>Bid Date</label></br><input style='width:250px' id='biddate' type='date' class='form-control' name='BidDate' value=$BidDate></div></br>";
    echo "<div class='form-group'><label for='releasedate'>Release Date</label></br><input style='width:250px' id='releasedate' type='date' class='form-control' name='ReleaseDate' value=$ReleaseDate></div></br>";
    echo "<div class='form-group'><label for='orderbydate'>Order By Date</label></br><input style='width:250px' id='orderbydate' type='date' class='form-control' name='OrderByDate' value=$OrderByDate></div></br>";
    echo "<div class='form-group'><label for='shipbydate'>Ship By Date</label></br><input style='width:250px' id='shipbydate' type='date' class='form-control' name='ShipByDate' value=$ShipByDate></div></br>";
    echo "<div class='form-group'><label for='phonenumber'>Phone Number</label></br><input style='width:250px' id='phonenumber' type='text' class='form-control' name='PhoneNumber' value=$PhoneNumber></div></br>";
    echo "<div class='form-group'><label for='pricenotes'>Price Notes</label></br><input style='width:250px' id='pricenotes' type='text' class='form-control' name='PriceNotes' value=$PriceNotes></div></br>";

    echo "<div class='form-group'><label for='image'>Logo Image</label></br><input id='image' type='file' name='Image' value=$Image></div></br>";
    echo "<div class='form-group'><label for='status'>Status</label></br><select name='Status'><option value=$Status>$Status</option><option value='Pending'>Pending</option><option value='Info'>Info</option><option value='Sold'>Sold</option><option value='Lost'>Lost</option></select></div></br></div>";


 }
?>
