<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_vendors where VendorId = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $id = $result['VendorId'];
    	$CompanyName = $result['CompanyName'];
    	$Address1 = $result['Address1'];
    	$Address2 = $result['Address2'];
    	$City = $result['City'];
    	$State = $result['State'];
    	$Zip = $result['Zip'];
    	$CompanyPhone = $result['CompanyPhone'];
    	$CompanyEmail = $result['CompanyEmail'];
    	$CompanyFax = $result['CompanyFax'];
    	$Notes = $result['Notes'];
      $Image = $result['Image'];
    }
    echo "<div class='container'><div class='form-group'><label for='companyname'>Company Name</label></br><input style='width:250px' id='companyname' type='text' class='form-control' name='CompanyName' value='".$CompanyName."'></div></br>";
    echo "<div class='form-group'><input type='hidden' class='form-control' name='VendorId' value=$id></div>";

    echo "<div class='form-group'><label for='address1'>Address 1</label></br><input style='width:250px' id='address1' type='text' class='form-control' name='Address1' value='".$Address1."'></div></br>";
    echo "<div class='form-group'><label for='address2'>Address 2</label></br><input style='width:250px' id='address2' type='text' class='form-control' name='Address2' value='".$Address2."'></div></br>";
    echo "<div class='form-group'><label for='city'>City</label></br><input style='width:250px' id='city' type='text' class='form-control' name='City' value='".$City."'></div></br>";
    echo "<div class='form-group'><label for='state'>State</label></br><input style='width:250px' id='state' type='text' class='form-control' name='State' value='".$State."'></div></br>";
    echo "<div class='form-group'><label for='zip'>Zip</label></br><input style='width:250px' id='zip' type='text' class='form-control' name='Zip' value=$Zip></div></br>";
    echo "<div class='form-group'><label for='compantphone'>Company Phone</label></br><input style='width:250px' id='companyphone' type='text' class='form-control' name='CompanyPhone' value=$CompanyPhone></div></br>";
    echo "<div class='form-group'><label for='companyemail'>Company Email</label></br><input style='width:250px' id='companyemail' type='text' class='form-control' name='CompanyEmail' value=$CompanyEmail></div></br>";
    echo "<div class='form-group'><label for='companyfax'>Company Fax</label></br><input style='width:250px' id='companyfax' type='text' class='form-control' name='CompanyFax' value=$CompanyFax></div></br>";
    echo "<div class='form-group'><label for='image'>Image</label></br><input id='image' type='file' name='Image' value=$Image></div></br>";
    echo "<div class='form-group'><label for='notes'>Notes</label></br><input style='width:250px' id='notes' type='text' class='form-control' name='Notes' value=$Notes></div></br></div>";


 }
?>
