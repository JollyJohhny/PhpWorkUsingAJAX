<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_inventory where InventoryId = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $id = $result['InventoryId'];
    	$StockNumber = $result['StockNumber'];
    	$Unit = $result['Unit'];
    	$Lbs = $result['Lbs'];
    	$Vendor = $result['Vendor'];
    	$Cost = $result['Cost'];
    	$Size = $result['Size'];
    	$Description = $result['Description'];
    	$Price1 = $result['Price1'];
    	$Price2 = $result['Price2'];
    	$Price3 = $result['Price3'];
    	$Price4 = $result['Price4'];
    	$Price5 = $result['Price5'];
    	$Price6 = $result['Price6'];

    	$Notes = $result['Notes'];
    	$Image = $result['Image'];
    }


    echo "<div class='container'><h3>Stock Number</h3><p>$StockNumber</p>";
    echo "<h3>Unit</h3><p>$Unit</p>";
    echo "<h3>Lbs/ft</h3><p>$Lbs</p>";
    echo "<h3>Vendor</h3><p>$Vendor</p>";
    echo "<h3>Cost</h3><p>$Cost</p>";
    echo "<h3>Size</h3><p>$Size</p>";
    echo "<h3>Desription</h3><p>$Description</p>";
    echo "<h3>Price 1</h3><p>$Price1</p>";
    echo "<h3>Price 2</h3><p>$Price2</p>";
    echo "<h3>Price 3</h3><p>$Price3</p>";
    echo "<h3>Price 4</h3><p>$Price4</p>";
    echo "<h3>Price 5</h3><p>$Price5</p>";
    echo "<h3>Price 6</h3><p>$Price6</p>";
    echo "<h3>Notes</h3><p>$Notes</p>";
    echo "<h3>Image</h3><p>$Image</p></div>";

 }
?>
