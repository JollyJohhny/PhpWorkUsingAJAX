<?php
	$host = 'localhost';
	$username = 'root';
	$password = '';
	$database = 'quotationsystem';
	$conn= mysqli_connect($host, $username, $password, $database);
?>
