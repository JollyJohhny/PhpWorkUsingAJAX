<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_inventory where InventoryId = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $id = $result['InventoryId'];
    	$StockNumber = $result['StockNumber'];
    	$Unit = $result['Unit'];
    	$Lbs = $result['Lbs'];
    	$Vendor = $result['Vendor'];
    	$Cost = $result['Cost'];
    	$Size = $result['Size'];
    	$Description = $result['Description'];
    	$Price1 = $result['Price1'];
    	$Price2 = $result['Price2'];
    	$Price3 = $result['Price3'];
    	$Price4 = $result['Price4'];
    	$Price5 = $result['Price5'];
    	$Price6 = $result['Price6'];

    	$Notes = $result['Notes'];
      $Image = $result['Image'];
    }
    echo "<div class='container'><div class='form-group'><label for='stocknumber'>Stock Number</label></br><input style='width:250px' id='stocknumber' type='text' class='form-control' name='StockNumber' value='".$StockNumber."'></div></br>";
    echo "<div class='form-group'><input type='hidden' class='form-control' name='InventoryId' value=$id></div>";

    echo "<div class='form-group'><label for='unit'>Unit</label></br><input style='width:250px' id='unit' type='text' class='form-control' name='Unit' value='".$Unit."'></div></br>";
    echo "<div class='form-group'><label for='lbs'>Lbs/ft</label></br><input style='width:250px' id='lbs' type='text' class='form-control' name='Lbs' value='".$Lbs."'></div></br>";
    echo "<div class='form-group'><label for='vendor'>Vendor Id</label></br><input style='width:250px' id='vendor' type='text' class='form-control' name='Vendor' value='".$Vendor."'></div></br>";
    echo "<div class='form-group'><label for='cost'>Cost</label></br><input style='width:250px' id='cost' type='text' class='form-control' name='Cost' value='".$Cost."'></div></br>";
    echo "<div class='form-group'><label for='size'>Size</label></br><input style='width:250px' id='size' type='text' class='form-control' name='Size' value=$Size></div></br>";
    echo "<div class='form-group'><label for='desription'>Description</label></br><input style='width:250px' id='description' type='text' class='form-control' name='Description' value=$Description></div></br>";
    echo "<div class='form-group'><label for='price1'>Price 1</label></br><input style='width:250px' id='price1' type='text' class='form-control' name='Price1' value=$Price1></div></br>";
    echo "<div class='form-group'><label for='price2'>Price 2</label></br><input style='width:250px' id='price2' type='text' class='form-control' name='Price2' value=$Price2></div></br>";
    echo "<div class='form-group'><label for='price3'>Price 3</label></br><input style='width:250px' id='price3' type='text' class='form-control' name='Price3' value=$Price3></div></br>";
    echo "<div class='form-group'><label for='price4'>Price 4</label></br><input style='width:250px' id='price1' type='text' class='form-control' name='Price4' value=$Price4></div></br>";
    echo "<div class='form-group'><label for='price5'>Price 5</label></br><input style='width:250px' id='price5' type='text' class='form-control' name='Price5' value=$Price5></div></br>";
    echo "<div class='form-group'><label for='price6'>Price 6</label></br><input style='width:250px' id='price6' type='text' class='form-control' name='Price6' value=$Price6></div></br>";

    echo "<div class='form-group'><label for='image'>Image</label></br><input id='image' type='file' name='Image' value=$Image></div></br>";
    echo "<div class='form-group'><label for='notes'>Notes</label></br><input style='width:250px' id='notes' type='text' class='form-control' name='Notes' value=$Notes></div></br></div>";


 }
?>
