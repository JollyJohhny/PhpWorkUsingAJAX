<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_customer_contacts where CustomerContactId = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $CustomerContactId = $result['CustomerCon tactId'];
    	$CompanyName = $result['CompanyName'];
    	$FirstName = $result['FirstName'];
    	$MiddleName = $result['MiddleName'];
    	$LastName = $result['LastName'];
    	$ContactPhoneNumber = $result['ContactPhoneNumber'];
    	$ContactCellNumber = $result['ContactCellNumber'];
    	$ContactEmail = $result['ContactEmail'];
    	$Notes = $result['Notes'];
    }
    echo "<div class='container'><div class='form-group'><label for='companyname'>Company Name</label></br><input style='width:250px' id='companyname' type='text' class='form-control' name='CompanyName' value='".$CompanyName."'></div></br>";
    echo "<div class='form-group'><input type='hidden' class='form-control' name='CustomerContactId' value=$CustomerContactId></div>";

    echo "<div class='form-group'><label for='firstname'>First Name</label></br><input style='width:250px' id='firstname' type='text' class='form-control' name='FirstName' value='".$FirstName."'></div></br>";
    echo "<div class='form-group'><label for='middlename'>Middle Name</label></br><input style='width:250px' id='middlename' type='text' class='form-control' name='MiddleName' value='".$MiddleName."'></div></br>";
    echo "<div class='form-group'><label for='lastname'>Last Name</label></br><input style='width:250px' id='lastname' type='text' class='form-control' name='LastName' value='".$LastName."'></div></br>";
    echo "<div class='form-group'><label for='contactphonenumber'>Contact Phone Number</label></br><input style='width:250px' id='contactphonenumber' type='text' class='form-control' name='ContactPhoneNumber' value='".$ContactPhoneNumber."'></div></br>";
    echo "<div class='form-group'><label for='contactcellnumber'>Contact Cell Number</label></br><input style='width:250px' id='contactcellnumber' type='text' class='form-control' name='ContactCellNumber' value=$ContactCellNumber></div></br>";
    echo "<div class='form-group'><label for='contactemail'>Contact Email</label></br><input style='width:250px' id='contactemail' type='text' class='form-control' name='ContactEmail' value=$ContactEmail></div></br>";
    echo "<div class='form-group'><label for='notes'>Notes</label></br><input style='width:250px' id='notes' type='text' class='form-control' name='Notes' value=$Notes></div></br></div>";


 }
?>
