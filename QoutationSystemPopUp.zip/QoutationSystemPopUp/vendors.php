<?php
	 include "dbConnection.php";
	$sql= "SELECT * FROM tbl_vendors";
	$resultOne = $conn->query($sql);
?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Quotation System</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="styles.css">
<style type="text/css">
    body {
        color: #566787;
		background: #f5f5f5;
		font-family: 'Varela Round', sans-serif;
		font-size: 13px;
	}
	.table-wrapper {
        background: #fff;
        padding: 20px 25px;
        margin: 30px 0;
		border-radius: 3px;
        box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
	.table-title {
		padding-bottom: 15px;
		background: #435d7d;
		color: #fff;
		padding: 16px 30px;
		margin: -20px -25px 10px;
		border-radius: 3px 3px 0 0;
    }
    .table-title h2 {
		margin: 5px 0 0;
		font-size: 24px;
	}
	.table-title .btn-group {
		float: right;
	}
	.table-title .btn {
		color: #fff;
		float: right;
		font-size: 13px;
		border: none;
		min-width: 50px;
		border-radius: 2px;
		border: none;
		outline: none !important;
		margin-left: 10px;
	}
	.table-title .btn i {
		float: left;
		font-size: 21px;
		margin-right: 5px;
	}
	.table-title .btn span {
		float: left;
		margin-top: 2px;
	}
    table.table tr th, table.table tr td {
        border-color: #e9e9e9;
		padding: 12px 15px;
		vertical-align: middle;
    }
	table.table tr th:first-child {
		width: 60px;
	}
	table.table tr th:last-child {
		width: 100px;
	}
    table.table-striped tbody tr:nth-of-type(odd) {
    	background-color: #fcfcfc;
	}
	table.table-striped.table-hover tbody tr:hover {
		background: #f5f5f5;
	}
    table.table th i {
        font-size: 13px;
        margin: 0 5px;
        cursor: pointer;
    }
    table.table td:last-child i {
		opacity: 0.9;
		font-size: 22px;
        margin: 0 5px;
    }
	table.table td a {
		font-weight: bold;
		color: #566787;
		display: inline-block;
		text-decoration: none;
		outline: none !important;
	}
	table.table td a:hover {
		color: #2196F3;
	}
	table.table td a.edit {
        color: #FFC107;
    }
    table.table td a.delete {
        color: #F44336;
    }
    table.table td i {
        font-size: 19px;
    }
	table.table .avatar {
		border-radius: 50%;
		vertical-align: middle;
		margin-right: 10px;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	/* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
	/* Modal styles */
	.modal .modal-dialog {
		max-width: 400px;
	}
	.modal .modal-header, .modal .modal-body, .modal .modal-footer {
		padding: 20px 30px;
	}
	.modal .modal-content {
		border-radius: 3px;
	}
	.modal .modal-footer {
		background: #ecf0f1;
		border-radius: 0 0 3px 3px;
	}
    .modal .modal-title {
        display: inline-block;
    }
	.modal .form-control {
		border-radius: 2px;
		box-shadow: none;
		border-color: #dddddd;
	}
	.modal textarea.form-control {
		resize: vertical;
	}
	.modal .btn {
		border-radius: 2px;
		min-width: 100px;
	}
	.modal form label {
		font-weight: normal;
	}
</style>
<script type="text/javascript">
$(document).ready(function(){
	// Activate tooltip
	$('[data-toggle="tooltip"]').tooltip();

	// Select/Deselect checkboxes
	var checkbox = $('table tbody input[type="checkbox"]');
	$("#selectAll").click(function(){
		if(this.checked){
			checkbox.each(function(){
				this.checked = true;
			});
		} else{
			checkbox.each(function(){
				this.checked = false;
			});
		}
	});
	checkbox.click(function(){
		if(!this.checked){
			$("#selectAll").prop("checked", false);
		}
	});
});
</script>
</head>
<body>
  <body>
  <!-- The Buttons -->
  <div style="margin-top:30px" class="container">

  <button type="button" class="mybtn" name="btnquotes" onclick="window.location.href = 'quotes.php'">Quotes</button>
  <button type="button" class="mybtn" name="btncustomers" onclick="window.location.href = 'customers.php'">Customers</button>
  <button type="button" class="mybtn" name="btnvendors" onclick="window.location.href = 'vendors.php'">Vendors</button>
  <button type="button" class="mybtn" name="btninventory" onclick="window.location.href = 'inventory.php'">Inventory</button>
  <button type="button" class="mybtn" name="btnreports" onclick="window.location.href = 'reports.php'">Reports</button>
  <button type="button" class="mybtn" name="btnunits" onclick="window.location.href = 'units.php'">Units</button>
  <button type="button" class="mybtn" name="btncompany" onclick="window.location.href = 'company.php'">Company</button>

  </div>
  <div class="container">


  <!-- Bootstrap Modal for Pop Up Details -->
  <!-- Button trigger modal -->



  <div style="margin-top:30px" class="container">

  </div>
  </body>




    <div class="container">
        <div class="table-wrapper">
            <div class="table-title">
                <div class="row">
                    <div class="col-sm-6">
						<h2>List of <b>Vendors</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addVendorModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New Vendor</span></a>
					</div>
                </div>
            </div>

            <table style="margin-top:20px" width='100%' border=2>

            <tr bgcolor='#CCCCCC'>
              <th>Company Name</th>
              <th>Address1</th>
              <th>Address2</th>
              <th>City</th>
              <th>State</th>
              <th>Zip</th>
              <th>Company Phone</th>
              <th>Company Email</th>
              <th>Company Fax</th>
              <th>Image</th>
              <th>Notes</th>
              <th>View</th>
							<th>Update</th>
							<th>Delete</th>
							<th>Contacts</th>

            </tr>
            <?php
            //foreach ($result as $key => $res) {
            while($res = mysqli_fetch_array($resultOne)) {
              echo "<tr>";
              echo "<td>".$res['CompanyName']."</td>";
              echo "<td>".$res['Address1']."</td>";
              echo "<td>".$res['Address2']."</td>";
              echo "<td>".$res['City']."</td>";
              echo "<td>".$res['State']."</td>";
              echo "<td>".$res['Zip']."</td>";
              echo "<td>".$res['CompanyPhone']."</td>";
              echo "<td>".$res['CompanyEmail']."</td>";
              echo "<td>".$res['CompanyFax']."</td>";
              echo "<td>".$res['Image']."</td>";
              echo "<td>".$res['Notes']."</td>";
              echo "<td><button class='mybtn' data-toggle='modal' data-target='#viewVendorModal' data-id='".$res['VendorId']."'>View</button></td>";
							echo "<td><button class='mybtn' data-toggle='modal' data-target='#updateVendorModal' data-id='".$res['VendorId']."'>Update</button></td>";
							echo "<td><button class='mybtn' data-toggle='modal' data-target='#deleteVendorModal' data-id='".$res['VendorId']."'>Delete</button></td>";
							echo "<td>"."<a href=vendorContacts.php?VendorId=$res[VendorId] ><button class='mybtn' style=height:30px id=mybtn>Conatct</button></a>"."</td>";
}
            ?>



            </table>

        </div>
    </div>
	<!-- PHP portion for insert -->

	<?php
	// $conn= mysqli_connect($host, $username, $password, $database);
	if(isset($_POST['Submit'])) {
	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["Image"]["name"]);
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	// Check if image file is a actual image or fake image

	$CompanyName = $_POST['CompanyName'];
	$Address1 = $_POST['Address1'];
	$Address2 = $_POST['Address2'];
	$City = $_POST['City'];
	$State = $_POST['State'];
	$Zip = $_POST['Zip'];
	$CompanyPhone = $_POST['CompanyPhone'];
	$CompanyEmail = $_POST['CompanyEmail'];
	$CompanyFax = $_POST['CompanyFax'];
	$Notes = $_POST['Notes'];




	$Image = $target_file;




	//insert data to database
	$Query = "insert into tbl_vendors(CompanyName,Address1,Address2,City,State,Zip,CompanyPhone,CompanyEmail,CompanyFax,Image,Notes) values('".$CompanyName."','".$Address1."','".$Address2."','".$City."','".$State."','".$Zip."','".$CompanyPhone."','".$CompanyEmail."','".$CompanyFax."','".$Image."','".$Notes."')";
	$result = mysqli_query($conn,$Query);
	if ($result){
		echo "<script>alert('Added Successfully!')</script>";
	}}

	 ?>
	<!-- Add Modal HTML -->
	<div id="addVendorModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">

					<div class="modal-header">
						<h4 class="modal-title">Add Vendor</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
						<form method="post" name="form1" enctype="multipart/form-data">
					    <div class="form-group">
					        <label for="companyname">Company Name</label>
					        <input style="width:250px" id="companyname" type="text" class="form-control" name="CompanyName" required>
					    </div>
					    <div class="form-group">
					        <label for="address1">Address1</label>
					        <input style="width:250px" id="address1" type="text" class="form-control" name="Address1" required>
					    </div>
					    <div class="form-group">
					        <label for="address2">Address2</label>
					        <input style="width:250px" id="address2" type="text" class="form-control" name="Address2" required>
					    </div>
					    <div class="form-group">
					        <label for="city">City</label>
					        <input style="width:250px" id="city" type="text" class="form-control" name="City" required>
					    </div>
					    <div class="form-group">
					        <label for="state">State</label>
					        <input style="width:250px" id="state" type="text" class="form-control" name="State" required>
					    </div>
					    <div class="form-group">
					        <label for="zip">Zip</label>
					        <input style="width:250px" id="zip" type="text" class="form-control" name="Zip" required>
					    </div>
					    <div class="form-group">
					        <label for="companyphone">Company Phone</label>
					        <input style="width:250px" id="companyphone" type="text" class="form-control" name="CompanyPhone" required>
					    </div>
					    <div class="form-group">
					        <label for="companyemail">Company Email</label>
					        <input style="width:250px" id="companyemail" type="text" class="form-control" name="CompanyEmail" required>
					    </div>
					    <div class="form-group">
					        <label for="companyfax">Company Fax</label>
					        <input style="width:250px" id="companyfax" type="text" class="form-control" name="CompanyFax" required>
					    </div>
					    <div class="form-group">
					        <label for="image">Image</label>
					<input type="file" name="Image" id="image">
					</div>
					    <div class="form-group">
					        <label for="notes">Notes</label>
					        <input style="width:250px" id="notes" type="text" class="form-control" name="Notes" required>
					    </div>
							<div class="modal-footer">
								<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
								<input type="submit" class="btn btn-success" name="Submit" value="Add">
							</div>
					</div>
				</form>

			</div>
		</div>
	</div>

	<!-- PHP portion for update -->

	<?php
	// $conn= mysqli_connect($host, $username, $password, $database);
	if(isset($_POST['Update'])) {
		$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["Image"]["name"]);
	$uploadOk = 1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	// Check if image file is a actual image or fake image
		$id = $_POST['VendorId'];
		$CompanyName = $_POST['CompanyName'];
		$Address1 = $_POST['Address1'];
		$Address2 = $_POST['Address2'];
		$City = $_POST['City'];
		$State = $_POST['State'];
		$Zip = $_POST['Zip'];
		$CompanyPhone = $_POST['CompanyPhone'];
		$CompanyEmail = $_POST['CompanyEmail'];
		$CompanyFax = $_POST['CompanyFax'];
		$Notes = $_POST['Notes'];
		$Image = $target_file;
			//redirectig to the display page. In our case, it is index.php
			$Query = "update tbl_vendors set CompanyName='".$CompanyName."',Address1='".$Address1."',Address2='".$Address2."',City='".$City."',State='".$State."',Zip='".$Zip."',CompanyPhone='".$CompanyPhone."',CompanyEmail='".$CompanyEmail."',CompanyFax='".$CompanyFax."',Image='".$Image."',Notes='".$Notes."' where VendorId='".$id."'";
			$result = mysqli_query($conn,$Query);
	if ($result){
		echo "<script>alert('Updated Successfully!')</script>";
	}}

	 ?>
	<!-- Bootstrap Modal event to fetch data for Update-->
	  <script type="text/javascript">
	  $(document).ready(function(){
	  $('#updateVendorModal').on('show.bs.modal', function (e) {
	      var rowid = $(e.relatedTarget).data('id');
	      $.ajax({
	          type : 'post',
	          url : 'update_vendor.php', //Here you will fetch records
	          data :  'rowid='+ rowid, //Pass $id
	          success : function(data){
	            $('.fetched-data').html(data);//Show fetched data from database
	          }
	      });
	   });
	});
	  </script>

		<!-- Update Modal HTML -->

	  <div id="updateVendorModal" class="modal fade">
			<div class="modal-dialog">
				<div class="modal-content">
					<form method="post" name="form1" enctype="multipart/form-data">
						<div class="modal-header">
							<h4 class="modal-title">Update Vendor</h4>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						</div>
						<div class="modal-body">
						</div>
						<form action="vendor.php" method="post" enctype="multipart/form-data">
							<div class="fetched-data">

	          </div>
						<div class="modal-footer">
							<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
							<input type="submit" class="btn btn-success" name="Update" value="Update">
						</div>
					</form>


					</form>
				</div>
			</div>
		</div>

<!-- Bootstrap Modal event to fetch data for View -->
  <script type="text/javascript">
  $(document).ready(function(){
  $('#viewVendorModal').on('show.bs.modal', function (e) {
      var rowid = $(e.relatedTarget).data('id');
      $.ajax({
          type : 'post',
          url : 'view_vendor.php', //Here you will fetch records
          data :  'rowid='+ rowid, //Pass $id
          success : function(data){
            $('.fetched-data').html(data);//Show fetched data from database
          }
      });
   });
});
  </script>

	<!-- View Modal HTML -->

  <div id="viewVendorModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form>
					<div class="modal-header">
						<h4 class="modal-title">View Vendor</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">
					</div>
          <div class="fetched-data">

          </div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-success" value="Print">
					</div>
				</form>
			</div>
		</div>
	</div>

<!-- PHP portion for Delete -->
<?php
include "dbConnection.php";
if(isset($_POST['Delete'])) {
	$id = $_POST['VendorId'];

	$DeleteQuery = "delete from tbl_vendors where VendorId='".$id."'";
	$result = mysqli_query($conn,$DeleteQuery);

	if ($result){
		echo "<script>alert('Deleted Successfully!')</script>";
	}
}

 ?>

	<!-- Bootstrap Modal event to fetch data for Delete -->
	  <script type="text/javascript">
	  $(document).ready(function(){
	  $('#deleteVendorModal').on('show.bs.modal', function (e) {
	      var rowid = $(e.relatedTarget).data('id');
	      $.ajax({
	          type : 'post',
	          url : 'delete_vendor.php', //Here you will fetch records
	          data :  'rowid='+ rowid, //Pass $id
	          success : function(data){
	            $('.fetched-data').html(data);//Show fetched data from database
	          }
	      });
	   });
	});
	  </script>

	<!-- Delete Modal HTML -->
	<div id="deleteVendorModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="post" action="vendors.php">
					<div class="modal-header">
						<h4 class="modal-title">Delete Vendor</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="fetched-data">

					</div>
					<div class="modal-body">
						<p>Are you sure you want to delete this Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-danger" name="Delete" value="Delete">
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- To Prevent Form Resubmission -->
	<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
</body>
</html>
