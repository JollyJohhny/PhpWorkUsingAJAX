<?php
include "dbConnection.php";

if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    echo "<div class='form-group'><input type='hidden' class='form-control' name='VendorContactId' value=$id></div>";
  }
 ?>
