<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_customer_contacts where CustomerContactId = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $CustomerContactId = $result['CustomerContactId'];
    	$CompanyName = $result['CompanyName'];
    	$FirstName = $result['FirstName'];
    	$MiddleName = $result['MiddleName'];
    	$LastName = $result['LastName'];
    	$ContactPhoneNumber = $result['ContactPhoneNumber'];
    	$ContactCellNumber = $result['ContactCellNumber'];
    	$ContactEmail = $result['ContactEmail'];
    	$Notes = $result['Notes'];
    }
    echo "<div class='container'><h3>Company Name</h3><p>$CompanyName</p>";

    echo "<h3>First Name</h3><p>$FirstName</p>";
    echo "<h3>Niddle Name</h3><p>$MiddleName</p>";
    echo "<h3>Last Name</h3><p>$LastName</p>";
    echo "<h3>Contact Phone Number</h3><p>$ContactPhoneNumber</p>";
    echo "<h3>Contact Cell Number</h3><p>$ContactCellNumber</p>";
    echo "<h3>Contact Email</h3><p>$ContactEmail</p>";
    echo "<h3>Notes</h3><p>$Notes</p></div>";

 }
?>
