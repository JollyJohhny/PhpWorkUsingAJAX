<?php
include "dbConnection.php";


if($_POST['rowid']) {
    $id = $_POST['rowid']; //escape string
    // Run the Query
    // Fetch Records

    $Query = "select * from tbl_vendors where VendorId = '".$id."'";
    $res = mysqli_query($conn,$Query);

    foreach ($res as $result) {
      $id = $result['VendorId'];
    	$CompanyName = $result['CompanyName'];
    	$Address1 = $result['Address1'];
    	$Address2 = $result['Address2'];
    	$City = $result['City'];
    	$State = $result['State'];
    	$Zip = $result['Zip'];
    	$CompanyPhone = $result['CompanyPhone'];
    	$CompanyEmail = $result['CompanyEmail'];
    	$CompanyFax = $result['CompanyFax'];
    	$Notes = $result['Notes'];
      $Image = $result['Image'];
    }
    echo "<div class='container'><h3>Company Name</h3><p>$CompanyName</p>";

    echo "<div class='form-group'><input type='hidden' class='form-control' name='VendorId' value=$id></div>";


    echo "<h3>Address1</h3><p>$Address1</p>";
    echo "<h3>Address2</h3><p>$Address2</p>";
    echo "<h3>City</h3><p>$City</p>";
    echo "<h3>State</h3><p>$State</p>";
    echo "<h3>Zip</h3><p>$Zip</p>";
    echo "<h3>Company Phone</h3><p>$CompanyPhone</p>";
    echo "<h3>Company Email</h3><p>$CompanyEmail</p>";
    echo "<h3>Company Fax</h3><p>$CompanyFax</p>";
    echo "<h3>Notes</h3><p>$Notes</p>";
    echo "<h3>Image</h3><p>$Image</p></div>";

 }
?>
